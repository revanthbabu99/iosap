//
//  ResultViewController.swift
//  discount
//
//  Created by Student on 4/6/22.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var enteredAmount: UILabel!
    
    @IBOutlet weak var enterDisc: UILabel!
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    
    var amount = ""
    var disc = ""
    var priceafterdisc = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        enteredAmount.text = enteredAmount.text! + amount
        
        enterDisc.text = enterDisc.text! + disc
        resultOutlet.text = resultOutlet.text! + priceafterdisc
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

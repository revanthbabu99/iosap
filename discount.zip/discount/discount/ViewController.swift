//
//  ViewController.swift
//  discount
//
//  Created by Student on 4/6/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var amountOutlet: UITextField!
    
    @IBOutlet weak var discountOutlet: UITextField!
    
    var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calcPressed(_ sender: UIButton) {
        var amount = Double(amountOutlet.text!)
        print(amount!)
        
        var discountRate = Double(discountOutlet.text!)
        print(discountRate!)
        
        priceAfterDiscount = amount! -
        (amount!*discountRate!/100)
        print(priceAfterDiscount)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "ResultSegue"{
            var destination = segue.destination as! ResultViewController
            
            destination.amount = amountOutlet.text!
            destination.disc = discountOutlet.text!
            destination.priceafterdisc = String(priceAfterDiscount)
        }
    }
    
}


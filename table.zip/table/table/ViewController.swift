//
//  ViewController.swift
//  table
//
//  Created by Student on 4/7/22.
//

import UIKit


class product{
    var productname : String?
    var productdesc : String?
    init(prodname:String, prodcategory:String){
        self.productname = prodname
        self.productdesc = prodcategory
    }
}
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productarray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableviewOutlet.dequeueReusableCell(withIdentifier: "Cell", for:  indexPath)
        
        cell.textLabel?.text = productarray[indexPath.row].productname
    return cell
    }
    
    
    @IBOutlet weak var tableviewOutlet: UITableView!
    var productarray = [product]()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableviewOutlet.delegate = self
        tableviewOutlet.dataSource = self
        
        let p1 = product(prodname: "MAcbook", prodcategory: "Apple")
        productarray.append(p1)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "AppD"{
            let destination = segue.destination as! ResultViewController
            
            destination.product =  productarray[(tableviewOutlet.indexPathForSelectedRow?.row)!]
            
        }
    }

}

